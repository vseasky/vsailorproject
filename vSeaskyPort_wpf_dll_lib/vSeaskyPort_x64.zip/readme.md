
vSeaskyPort静态库&动态库 是基于 `WIN-API` 和 `Seasky` 协议编写的供 C# WPF 调用的动态链接库，可以最大程度弥补 WPF 上位机和 QT 上位机之间的性能差距。